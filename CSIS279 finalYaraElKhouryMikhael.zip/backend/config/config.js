var config = {
    PORT :27017,
    NODE_ENV: 'development',
    HOST:'localhost',
    DB:'foodwaste-final'
}
module.exports = {config: config};